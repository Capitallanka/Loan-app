// Loan range slider amount update
const range = document.getElementById('loanRange');
const amount = document.getElementById('loanAmount');

range.addEventListener('input', function () {
  let value = parseInt(this.value).toLocaleString('en-IN');
  amount.textContent = value + ' Rs';
});

const translations = { ... }; // The full translation object is too large to fit here.